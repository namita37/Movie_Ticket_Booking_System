import movie.ConsoleOperations;
import movie.ConsoleHelper;

import java.util.Scanner;

public class Console {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        while (true) {

            System.out.println("\n===========================");
            System.out.println(" 🎬 MOVIE BOOKING SYSTEM");
            System.out.println("===========================");

            System.out.println("1. Show Movies");
            System.out.println("2. Show Seats");
            System.out.println("3. Book Ticket");
            System.out.println("4. Cancel Ticket");
            System.out.println("5. Booking History");
            System.out.println("6. Exit");

            System.out.print("Enter Choice: ");
            int ch = sc.nextInt();

            switch (ch) {

                case 1:
                    ConsoleOperations.showMovies();
                    break;

                case 2:
                    ConsoleHelper.showSeats();
                    break;

                case 3:
                    ConsoleOperations.bookTicket();
                    break;

                case 4:
                    ConsoleOperations.cancelTicket();
                    break;

                case 5:
                    ConsoleOperations.showHistory();
                    break;

                case 6:
                    System.exit(0);

                default:
                    System.out.println("❌ Invalid Choice");
            }
        }
    }
}