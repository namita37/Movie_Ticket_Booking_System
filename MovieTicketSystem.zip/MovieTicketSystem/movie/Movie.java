package movie;

public class Movie {

    int movieId;
    String movieName;
    int availableSeats;

    public Movie(int movieId, String movieName, int availableSeats) {
        this.movieId = movieId;
        this.movieName = movieName;
        this.availableSeats = availableSeats;
    }
}