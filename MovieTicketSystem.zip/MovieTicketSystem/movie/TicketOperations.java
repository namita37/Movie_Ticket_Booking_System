package movie;

import java.sql.*;
import javax.swing.*;

public class TicketOperations {
	

    // LOAD MOVIES
    public static void loadMovies(JComboBox<String> box) {

        try {
            Connection con = DBConnection.getConnection();

            ResultSet rs = con.prepareStatement("SELECT * FROM movies").executeQuery();

            box.removeAllItems();

            while (rs.next()) {
                box.addItem(rs.getInt(1) + " - " + rs.getString(2));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CHECK BOOKED SEAT
    public static boolean isBooked(int movieId, String seat) {

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "SELECT seat_numbers FROM bookings WHERE movie_id=?"
            );

            ps.setInt(1, movieId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String s = rs.getString(1);
                if (s != null && s.contains(seat)) {
                    return true;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    // BOOK TICKET
    public static int bookTicket(String name, int movieId, String seats, int count) {

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO bookings(customer_name,movie_id,seats_booked,seat_numbers) VALUES (?,?,?,?)",
                Statement.RETURN_GENERATED_KEYS
            );

            ps.setString(1, name);
            ps.setInt(2, movieId);
            ps.setInt(3, count);
            ps.setString(4, seats);

            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            int id = 0;

            if (rs.next()) {
                id = rs.getInt(1);
            }

            PreparedStatement ps2 = con.prepareStatement(
                "UPDATE movies SET available_seats = available_seats - ? WHERE movie_id=?"
            );

            ps2.setInt(1, count);
            ps2.setInt(2, movieId);

            ps2.executeUpdate();

            FileManager.saveTicket(id, name, movieId, seats);

            return id;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return -1;
    }

    // HISTORY
    public static void showHistory() {

        try {
            Connection con = DBConnection.getConnection();

            ResultSet rs = con.prepareStatement("SELECT * FROM bookings").executeQuery();

            System.out.println("\n--- HISTORY ---");

            while (rs.next()) {
                System.out.println(
                    rs.getInt(1) + " | " +
                    rs.getString(2) + " | " +
                    rs.getInt(3) + " | " +
                    rs.getInt(4) + " | " +
                    rs.getString(5)
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CANCEL (SAFE)
    public static void cancelTicket(int id) {

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM bookings WHERE booking_id=?"
            );

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (!rs.next()) {
                JOptionPane.showMessageDialog(null, "❌ Invalid Booking ID");
                return;
            }

            int seats = rs.getInt("seats_booked");
            int movieId = rs.getInt("movie_id");

            PreparedStatement ps2 = con.prepareStatement(
                "DELETE FROM bookings WHERE booking_id=?"
            );

            ps2.setInt(1, id);
            ps2.executeUpdate();

            PreparedStatement ps3 = con.prepareStatement(
                "UPDATE movies SET available_seats = available_seats + ? WHERE movie_id=?"
            );

            ps3.setInt(1, seats);
            ps3.setInt(2, movieId);
            ps3.executeUpdate();

            JOptionPane.showMessageDialog(null, "✅ Ticket Cancelled");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}