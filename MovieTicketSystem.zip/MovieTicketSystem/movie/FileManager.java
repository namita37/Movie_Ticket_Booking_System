package movie;

import java.io.FileWriter;

public class FileManager {

    public static void saveTicket(int id, String name, int movieId, String seats) {

        try {

            FileWriter fw = new FileWriter("Ticket_" + id + ".txt");

            fw.write("===== MOVIE TICKET =====\n");
            fw.write("Ticket ID : " + id + "\n");
            fw.write("Name      : " + name + "\n");
            fw.write("Movie ID  : " + movieId + "\n");
            fw.write("Seats     : " + seats + "\n");
            fw.write("========================\n");

            fw.close();

        } catch (Exception e) {
            System.out.println("File Error: " + e.getMessage());
        }
    }
}