package movie;

import java.sql.*;

public class DBConnection {

    private static Connection con;

    public static Connection getConnection() {

        try {
            if (con == null || con.isClosed()) {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/movie_db",
                    "root",
                    ""
                );
            }
        } catch (Exception e) {
            System.out.println("DB Error: " + e.getMessage());
        }

        return con;
    }
}