package movie;

import java.util.Scanner;

public class ConsoleHelper {

    public static void showSeats() {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Movie ID: ");
        int movieId = sc.nextInt();

        System.out.println("\n🪑 SEAT LAYOUT");

        for (int i = 0; i < 5; i++) {

            for (int j = 1; j <= 10; j++) {

                String seat = (char)('A' + i) + "" + j;

                if (ConsoleOperations.isBooked(movieId, seat)) {
                    System.out.print("[XX] ");
                } else {
                    System.out.print("[" + seat + "] ");
                }
            }

            System.out.println();
        }
    }
}