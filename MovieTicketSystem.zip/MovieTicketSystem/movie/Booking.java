package movie;

public class Booking {

    String name;
    int movieId;
    int seats;
    String seatNumbers;

    public Booking(String name, int movieId, int seats, String seatNumbers) {
        this.name = name;
        this.movieId = movieId;
        this.seats = seats;
        this.seatNumbers = seatNumbers;
    }
}