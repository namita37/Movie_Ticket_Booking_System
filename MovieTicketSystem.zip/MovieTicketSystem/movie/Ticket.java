package movie;

public class Ticket {

    int bookingId;
    String name;
    int movieId;
    int seats;
    String seatNumbers;

    public Ticket(int bookingId, String name, int movieId, int seats, String seatNumbers) {
        this.bookingId = bookingId;
        this.name = name;
        this.movieId = movieId;
        this.seats = seats;
        this.seatNumbers = seatNumbers;
    }
}