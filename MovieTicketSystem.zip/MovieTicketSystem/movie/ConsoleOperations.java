package movie;

import java.sql.*;
import java.util.Scanner;

public class ConsoleOperations {

    static Scanner sc = new Scanner(System.in);

    // SHOW MOVIES
    public static void showMovies() {

        try {

            Connection con = DBConnection.getConnection();

            ResultSet rs = con.prepareStatement(
                "SELECT * FROM movies"
            ).executeQuery();

            System.out.println("\n🎬 MOVIES");

            while (rs.next()) {

                System.out.println(
                    rs.getInt(1) + " - " +
                    rs.getString(2) +
                    " | Seats: " +
                    rs.getInt(3)
                );
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // CHECK BOOKED
    public static boolean isBooked(int movieId, String seat) {

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "SELECT seat_numbers FROM bookings WHERE movie_id=?"
            );

            ps.setInt(1, movieId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                String s = rs.getString(1);

                if (s != null && s.contains(seat)) {
                    return true;
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }

        return false;
    }

    // BOOK
    public static void bookTicket() {

        try {

            System.out.print("Enter Name: ");
            sc.nextLine();
            String name = sc.nextLine();

            showMovies();

            System.out.print("Enter Movie ID: ");
            int movieId = sc.nextInt();

            System.out.print("How many seats: ");
            int count = sc.nextInt();
            sc.nextLine();

            String seats = "";

            for (int i = 0; i < count; i++) {

                System.out.print("Enter Seat: ");
                String seat = sc.nextLine().toUpperCase();

                if (isBooked(movieId, seat)) {

                    System.out.println("❌ Already Booked");
                    i--;

                } else {

                    seats += seat + " ";
                }
            }

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO bookings(customer_name,movie_id,seats_booked,seat_numbers) VALUES (?,?,?,?)",
                Statement.RETURN_GENERATED_KEYS
            );

            ps.setString(1, name);
            ps.setInt(2, movieId);
            ps.setInt(3, count);
            ps.setString(4, seats);

            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();

            int id = 0;

            if (rs.next()) {
                id = rs.getInt(1);
            }

            PreparedStatement ps2 = con.prepareStatement(
                "UPDATE movies SET available_seats=available_seats-? WHERE movie_id=?"
            );

            ps2.setInt(1, count);
            ps2.setInt(2, movieId);

            ps2.executeUpdate();

            FileManager.saveTicket(id, name, movieId, seats);

            System.out.println("🎟 Booking Successful");
            System.out.println("Booking ID: " + id);

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // HISTORY
    public static void showHistory() {

        try {

            Connection con = DBConnection.getConnection();

            ResultSet rs = con.prepareStatement(
                "SELECT * FROM bookings"
            ).executeQuery();

            System.out.println("\n📜 HISTORY");

            while (rs.next()) {

                System.out.println(
                    rs.getInt(1) + " | " +
                    rs.getString(2) + " | " +
                    rs.getString(5)
                );
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // CANCEL
    public static void cancelTicket() {

        try {

            System.out.print("Enter Booking ID: ");
            int id = sc.nextInt();

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM bookings WHERE booking_id=?"
            );

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (!rs.next()) {

                System.out.println("❌ Invalid ID");
                return;
            }

            int seats = rs.getInt("seats_booked");
            int movieId = rs.getInt("movie_id");

            PreparedStatement ps2 = con.prepareStatement(
                "DELETE FROM bookings WHERE booking_id=?"
            );

            ps2.setInt(1, id);
            ps2.executeUpdate();

            PreparedStatement ps3 = con.prepareStatement(
                "UPDATE movies SET available_seats=available_seats+? WHERE movie_id=?"
            );

            ps3.setInt(1, seats);
            ps3.setInt(2, movieId);

            ps3.executeUpdate();

            System.out.println("✅ Ticket Cancelled");

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}