import movie.*;
import javax.swing.*;
import java.awt.*;

public class Main extends JFrame {

    JComboBox<String> movies;
    JPanel panel;

    JButton[][] seats = new JButton[5][10];
    boolean[][] selected = new boolean[5][10];

    public Main() {

        setTitle("Movie Booking System");
        setSize(900, 600);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        movies = new JComboBox<>();
        movies.setBounds(50, 20, 250, 30);
        add(movies);

        TicketOperations.loadMovies(movies);

        JButton load = new JButton("Load");
        JButton book = new JButton("Book");
        JButton history = new JButton("History");
        JButton cancel = new JButton("Cancel");

        load.setBounds(320, 20, 100, 30);
        book.setBounds(440, 20, 100, 30);
        history.setBounds(560, 20, 100, 30);
        cancel.setBounds(680, 20, 100, 30);

        add(load);
        add(book);
        add(history);
        add(cancel);

        panel = new JPanel();
        panel.setBounds(50, 80, 800, 400);
        panel.setLayout(new GridLayout(5, 10));
        add(panel);

        load.addActionListener(e -> createGrid());

        book.addActionListener(e -> bookSeats());

        history.addActionListener(e -> TicketOperations.showHistory());

        cancel.addActionListener(e -> {
            String id = JOptionPane.showInputDialog("Enter Booking ID:");
            if (id != null && !id.isEmpty()) {
                TicketOperations.cancelTicket(Integer.parseInt(id));
            }
        });

        setVisible(true);
    }

    void createGrid() {

        panel.removeAll();

        String m = (String) movies.getSelectedItem();

        if (m == null) {
            JOptionPane.showMessageDialog(this, "Select Movie First!");
            return;
        }

        int movieId = Integer.parseInt(m.split(" - ")[0]);

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 10; j++) {

                JButton b = new JButton((char)('A' + i) + "" + (j + 1));

                int r = i, c = j;

                if (TicketOperations.isBooked(movieId, b.getText())) {
                    b.setBackground(Color.RED);
                    b.setEnabled(false);
                } else {
                    b.setBackground(Color.GREEN);

                    b.addActionListener(e -> {
                        selected[r][c] = !selected[r][c];
                        b.setBackground(selected[r][c] ? Color.YELLOW : Color.GREEN);
                    });
                }

                seats[i][j] = b;
                panel.add(b);
            }
        }

        panel.revalidate();
        panel.repaint();
    }

    void bookSeats() {

        String m = (String) movies.getSelectedItem();

        if (m == null) {
            JOptionPane.showMessageDialog(this, "Select Movie First!");
            return;
        }

        int movieId = Integer.parseInt(m.split(" - ")[0]);

        String name = JOptionPane.showInputDialog("Enter Name:");

        if (name == null || name.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name required!");
            return;
        }

        String seatText = "";
        int count = 0;

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 10; j++) {
                if (selected[i][j]) {
                    seatText += seats[i][j].getText() + " ";
                    count++;
                }
            }
        }

        if (count == 0) {
            JOptionPane.showMessageDialog(this, "Select at least one seat!");
            return;
        }

        int id = TicketOperations.bookTicket(name, movieId, seatText, count);

        JOptionPane.showMessageDialog(this,
            "Booked Successfully!\nTicket ID: " + id
        );

        // RESET GRID AFTER BOOKING
        createGrid();
    }

    public static void main(String[] args) {
        new Main();
    }
}